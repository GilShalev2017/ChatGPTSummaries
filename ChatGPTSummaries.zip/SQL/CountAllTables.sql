select count(Id)
from Dblinks;

select count(Id)
from GeneAliases;

select count(Id)
from Genes;

select count(Id)
from GeneSummaries;