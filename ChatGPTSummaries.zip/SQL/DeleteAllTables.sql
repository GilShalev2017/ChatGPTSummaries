delete DbLinks
delete GeneAliases
delete GeneSummaries
delete Genes