/* 2 ways to find Cusomters who didn't perform any order*/
select c.CustomerID
from Customers c
LEFT outer JOIN Orders o on o.CustomerID = c.CustomerID
where o.OrderID is NULL
group by c.CustomerID, o.OrderID


select CustomerID
from Customers c
where CustomerID not in
( 
select c.CustomerID
from Orders o 
JOIN Customers s on c.CustomerID = o.CustomerID)

/* All customers even if not performed any order*/
SELECT c.CustomerID, c.CompanyName, o.OrderID 
FROM Customers c LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
ORDER BY c.CompanyName;

/* Products whose price is above AVG product price - needs subquery*/
select ProductName, UnitPrice, (select Avg(UnitPrice) from Products) as AvgPrice
from products
where UnitPrice > (select Avg(UnitPrice) from Products)
group by ProductName, UnitPrice


/* update products using subquery*/
/* update using set! */
Update Products
set UnitPrice = UnitPrice * 1.1 where CategoryID in
(select p.CategoryID
from Products p
JOIN Categories c on p.CategoryID = c.CategoryID
where c.CategoryName = 'Beverages')

UPDATE Products 
SET UnitPrice = UnitPrice * 1.10
WHERE CategoryID in 
(SELECT CategoryID
FROM Categories 
WHERE CategoryName = 'Beverages');

/* delete */
delete
from orders
where OrderDate < '1993-01-01'

/* Insert into using columns list and Values */
Insert into Customers (CustomerID, CompanyName, ContactName)
Values ('Broke','Gil','Shalev')

/* Using Case to add a column (keywords: CASE WHEN THEN ELSE END) */
SELECT ProductName, UnitPrice,
CASE WHEN UnitPrice < 20 THEN 'Cheap'
     WHEN UnitPrice BETWEEN 20 AND 50 THEN 'Moderate'
	 ELSE 'Expensive' END 
AS PriceCategory 
FROM Products
order by UnitPrice;

/* Upper, Lower string methods*/
select Upper(CompanyName), Lower(ContactName)
FROM Customers

/* filter by dates */
select OrderID, OrderDate
from Orders
Where OrderDate <= '1997-12-31' and OrderDate >= '1997-10-01'

/* Rak method (keywords: RANK() OVER PARTITION) */
SELECT ProductID, ProductName, CategoryID, UnitPrice, RANK() OVER (PARTITION BY CategoryID ORDER BY UnitPrice DESC) AS PriceRank 
FROM Products
Order by CategoryID ,PriceRank

Select Top 3 UnitPrice
from products 
Order by UnitPrice Desc

/* using temporarily table (Keywords: WITH AS ROW_NUMBER() OVER PARTITION) */
WITH RankedProducts AS (
    SELECT ProductID, ProductName, CategoryID, UnitPrice,
           ROW_NUMBER() OVER (PARTITION BY CategoryID ORDER BY UnitPrice DESC) AS RowNumber
    FROM Products
)
SELECT ProductID, ProductName, CategoryID, UnitPrice
FROM RankedProducts
WHERE RowNumber <= 3
ORDER BY CategoryID, UnitPrice DESC;

/* explaining first what is ROW_NUMBER(): it simply numering the row number for each partition
and then saving the results to a temporarily table, and then using this table*/
With RankedProducts AS (
    SELECT ProductID, ProductName, CategoryID, UnitPrice,
           ROW_NUMBER() OVER (PARTITION BY CategoryID ORDER BY UnitPrice DESC) AS RowNumber
    FROM Products
)
Select * from RankedProducts

/* Create VIEW (Keyword: AS) */
CREATE VIEW CustomerOrderTotals AS
SELECT c.CustomerID, c.CompanyName, COUNT(o.OrderID) AS TotalOrders, SUM(od.UnitPrice * od.Quantity) AS TotalAmount
FROM Customers c 
JOIN Orders o ON c.CustomerID = o.CustomerID 
JOIN [Order Details] od ON o.OrderID = od.OrderID
GROUP BY c.CustomerID, c.CompanyName;

/* Using a View */
SELECT * FROM CustomerOrderTotals;

/* combination of group by and aggreagtion on the grouped by column */
SELECT c.CategoryName, AVG(p.UnitPrice) AS AvgPrice
FROM Products p
JOIN Categories c ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryName

SELECT c.CategoryName, p.UnitPrice
FROM Products p
JOIN Categories c ON p.CategoryID = c.CategoryID and c.CategoryName = 'Seafood'
GROUP BY c.CategoryName, p.UnitPrice 

/* subquery to calculate first the AVG value */
SELECT ProductID, ProductName, UnitPrice,(SELECT AVG(UnitPrice) FROM Products)
FROM Products
WHERE UnitPrice > (SELECT AVG(UnitPrice) FROM Products);

/* 3 ways to show customers who performed at least one order using DISTINCT or Exists*/
select DISTINCT c.CustomerID,c.CompanyName
from Customers c
JOIN orders o on c.CustomerID = o.CustomerID

select C.CustomerID, c.CompanyName
from Customers c 
where Exists (select 1 from Orders o where o.CustomerID = c.CustomerID)

select c.CustomerID, CompanyName, Count(OrderID) as TotalOrders
from Customers c
JOIN Orders o on c.CustomerID = o.CustomerID
group by c.CustomerID, CompanyName
Having Count(OrderID) >= 1
order by c.CustomerID Asc


